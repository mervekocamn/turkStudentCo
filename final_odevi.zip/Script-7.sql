-- 1. MEMBERS (Üyeler) Tablosu
CREATE TABLE Members (
    member_id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    registration_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL
);

-- 2. CATEGORIES (Kategoriler) Tablosu
CREATE TABLE Categories (
    category_id SMALLINT PRIMARY KEY,
    category_name VARCHAR(100) UNIQUE NOT NULL
);

-- 3. COURSES (Eğitimler) Tablosu
CREATE TABLE Courses (
    course_id SERIAL PRIMARY KEY,
    course_name VARCHAR(200) NOT NULL,
    description TEXT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    instructor VARCHAR(100) NOT NULL,
    category_id SMALLINT NOT NULL,
    CONSTRAINT fk_category
        FOREIGN KEY (category_id)
        REFERENCES Categories(category_id)
        ON DELETE CASCADE
);

-- 4. ENROLLMENTS (Katılımlar) Tablosu
CREATE TABLE Enrollments (
    enrollment_id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    enrollment_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_member
        FOREIGN KEY (member_id)
        REFERENCES Members(member_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_course
        FOREIGN KEY (course_id)
        REFERENCES Courses(course_id)
        ON DELETE CASCADE
);

-- 5. CERTIFICATES (Sertifikalar) Tablosu
CREATE TABLE Certificates (
    certificate_id SERIAL PRIMARY KEY,
    certificate_code VARCHAR(100) UNIQUE NOT NULL,
    issue_date DATE NOT NULL
);

-- 6. CERTIFICATE ASSIGNMENTS (Sertifika Atamaları) Tablosu
CREATE TABLE CertificateAssignments (
    assignment_id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL,
    certificate_id INTEGER NOT NULL,
    assignment_date DATE NOT NULL DEFAULT CURRENT_DATE,
    CONSTRAINT fk_member_certificate
        FOREIGN KEY (member_id)
        REFERENCES Members(member_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_certificate
        FOREIGN KEY (certificate_id)
        REFERENCES Certificates(certificate_id)
        ON DELETE CASCADE
);

-- 7. BLOG POSTS (Blog Gönderileri) Tablosu
CREATE TABLE BlogPosts (
    post_id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    publish_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    author_id INTEGER NOT NULL,
    CONSTRAINT fk_author
        FOREIGN KEY (author_id)
        REFERENCES Members(member_id)
        ON DELETE CASCADE
);
